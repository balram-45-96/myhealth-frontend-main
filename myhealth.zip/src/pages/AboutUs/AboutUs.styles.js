import styled from "styled-components";

export const SCContainerBody = styled.div``;
