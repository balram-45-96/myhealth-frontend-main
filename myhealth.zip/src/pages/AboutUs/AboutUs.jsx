import React from "react";
import { SCContainerBody } from "./AboutUs.styles";

const AboutUs = () => {
  return <SCContainerBody></SCContainerBody>;
};

export default AboutUs;
