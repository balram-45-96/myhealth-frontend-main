import React from "react";
import { StyledLayout } from "./Layout.styles";

const Layout = ({ children }) => {
  return <StyledLayout>{children}</StyledLayout>;
};

export default Layout;
